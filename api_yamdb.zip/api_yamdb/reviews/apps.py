from django.apps import AppConfig


class RewiewsConfig(AppConfig):
    name = 'rewiews'
